function t_eval ()
{
   return eval("("+ document.getCookie(this.CookieName) +")");
}